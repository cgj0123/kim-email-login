<?php
/*
Plugin Name: Kim email login
Plugin URI: https://blog.lekims.com/
Description: 使用 SMTP 配置和邮件统计实现的安全 WordPress 邮件管理.
Version: 1.1.4
Author: kim
Text Domain: kim-email-login
License: GPLv2 or later
*/

if (!defined('ABSPATH')) {
    exit; // 直接访问时退出
}

// 定义常量
define('KIM_EMAIL_LOGIN_OPTION', 'kim_email_login_settings');
define('KIM_EMAIL_STATS_OPTION', 'kim_email_login_stats');
define('KIM_EMAIL_LOGIN_VERSION', '1.1.4');
define('KIM_EMAIL_LOGIN_DIR', plugin_dir_path(__FILE__));
define('KIM_EMAIL_LOGIN_URL', plugin_dir_url(__FILE__));

// 加载语言包
function kim_email_login_load_textdomain() {
    load_plugin_textdomain('kim-email-login', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'kim_email_login_load_textdomain');

// 加密函数
function kim_email_login_encrypt($data, $key = '') {
    if (empty($key)) {
        $key = defined('AUTH_KEY') ? AUTH_KEY : 'default-key-1234567890';
    }
    
    // 确保密钥长度符合 AES-256-CBC 要求 (32字节)
    $key = substr(hash('sha256', $key), 0, 32);
    
    $iv_length = openssl_cipher_iv_length('aes-256-cbc');
    $iv = openssl_random_pseudo_bytes($iv_length);
    
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, 0, $iv);
    if ($encrypted === false) {
        return false;
    }
    
    return base64_encode($encrypted . '::' . $iv);
}

function kim_email_login_decrypt($data, $key = '') {
    if (empty($key)) {
        $key = defined('AUTH_KEY') ? AUTH_KEY : 'default-key-1234567890';
    }
    
    // 确保密钥长度符合 AES-256-CBC 要求 (32字节)
    $key = substr(hash('sha256', $key), 0, 32);
    
    list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
    return openssl_decrypt($encrypted_data, 'aes-256-cbc', $key, 0, $iv);
}

// 获取设置
function kim_email_login_get_settings() {
    $defaults = array(
        'smtp_host'       => '',
        'smtp_port'       => '587',
        'smtp_username'   => '',
        'smtp_password'   => '',
        'smtp_encryption' => 'tls',
        'from_email'      => '',
        'from_name'       => get_bloginfo('name'),
        'disable_wp_mail' => false,
        'debug_mode'      => false,
        'smtp_timeout'    => 15,
        'smtp_auto_tls'   => true
    );
    
    $settings = get_option(KIM_EMAIL_LOGIN_OPTION, array());
    return wp_parse_args($settings, $defaults);
}

// 激活钩子
function kim_email_login_activate() {
    $default_settings = array(
        'smtp_host'       => '',
        'smtp_port'       => '587',
        'smtp_username'   => '',
        'smtp_password'   => '',
        'smtp_encryption' => 'tls',
        'from_email'      => '',
        'from_name'       => get_bloginfo('name'),
        'disable_wp_mail' => false,
        'debug_mode'      => false,
        'smtp_timeout'    => 15,
        'smtp_auto_tls'   => true
    );
    
    if (!get_option(KIM_EMAIL_LOGIN_OPTION)) {
        add_option(KIM_EMAIL_LOGIN_OPTION, $default_settings);
    }
    
    // 初始化统计数组
    if (!get_option(KIM_EMAIL_STATS_OPTION)) {
        add_option(KIM_EMAIL_STATS_OPTION, array(
            'sent_success' => 0,
            'sent_failed' => 0,
            'received_success' => 0,
            'received_failed' => 0
        ));
    }
    
    if (!wp_next_scheduled('kim_email_login_weekly_event')) {
        wp_schedule_event(time(), 'weekly', 'kim_email_login_weekly_event');
    }
    
    if (!get_option('kim_email_login_capability')) {
        add_option('kim_email_login_capability', 'manage_options');
    }
}
register_activation_hook(__FILE__, 'kim_email_login_activate');

// 停用钩子
function kim_email_login_deactivate() {
    wp_clear_scheduled_hook('kim_email_login_weekly_event');
}
register_deactivation_hook(__FILE__, 'kim_email_login_deactivate');

// 卸载钩子
function kim_email_login_uninstall() {
    delete_option(KIM_EMAIL_LOGIN_OPTION);
    delete_option(KIM_EMAIL_STATS_OPTION);
    delete_option('kim_email_login_capability');
    wp_clear_scheduled_hook('kim_email_login_weekly_event');
}
register_uninstall_hook(__FILE__, 'kim_email_login_uninstall');

// 自动检测 SMTP 配置（修复版）
function kim_email_login_auto_check_config() {
    if (!isset($_GET['page']) || $_GET['page'] !== 'kim_email_login' || isset($_POST['kim_email_login_save'])) {
        return;
    }

    $settings = kim_email_login_get_settings();
    
    $required_fields = array(
        'smtp_host' => __('SMTP 主机', 'kim-email-login'),
        'smtp_port' => __('SMTP 端口', 'kim-email-login'),
        'smtp_username' => __('SMTP 用户名', 'kim-email-login')
    );
    
    $missing_fields = array();
    foreach ($required_fields as $field => $name) {
        if (empty($settings[$field])) {
            $missing_fields[] = $name;
        }
    }
    
    if (!empty($missing_fields)) {
        add_settings_error(
            'kim_email_login_messages', 
            'kim_email_login_config_missing',
            sprintf(
                __('配置不完整，缺少以下字段：%s。请先填写这些必填项。', 'kim-email-login'),
                implode(', ', $missing_fields)
            ),
            'error'
        );
        return false;
    }
    
    try {
        $result = kim_email_login_test_connection($settings, true);
        if ($result) {
            add_settings_error(
                'kim_email_login_messages',
                'kim_email_login_connection_success',
                __('自动检测：SMTP 连接成功！', 'kim-email-login'),
                'success'
            );
        }
        return $result;
    } catch (Exception $e) {
        add_settings_error(
            'kim_email_login_messages',
            'kim_email_login_connection_failed',
            sprintf(
                __('自动检测：SMTP 连接失败 - %s', 'kim-email-login'),
                $e->getMessage()
            ),
            'error'
        );
        return false;
    }
}
add_action('admin_init', 'kim_email_login_auto_check_config');

// 添加管理菜单
function kim_email_login_add_admin_menu() {
    $capability = get_option('kim_email_login_capability', 'manage_options');
    
    add_options_page(
        __('Kim 邮件登录设置', 'kim-email-login'),
        __('Kim 邮件登录', 'kim-email-login'),
        $capability,
        'kim_email_login',
        'kim_email_login_settings_page'
    );
    
    add_action('wp_dashboard_setup', 'kim_email_login_add_dashboard_widget');
}
add_action('admin_menu', 'kim_email_login_add_admin_menu');

// 仪表盘小工具
function kim_email_login_add_dashboard_widget() {
    $capability = get_option('kim_email_login_capability', 'manage_options');
    if (current_user_can($capability)) {
        wp_add_dashboard_widget(
            'kim_email_login_stats_widget',
            __('邮件统计', 'kim-email-login'),
            'kim_email_login_dashboard_widget_content'
        );
    }
}

// 仪表盘小工具内容
function kim_email_login_dashboard_widget_content() {
    $stats = get_option(KIM_EMAIL_STATS_OPTION);
    ?>
    <div class="kim-email-stats">
        <div class="stat-row">
            <div class="stat-box sent-success">
                <h3><?php _e('发送成功', 'kim-email-login'); ?></h3>
                <p><?php echo esc_html($stats['sent_success']); ?></p>
            </div>
            <div class="stat-box sent-failed">
                <h3><?php _e('发送失败', 'kim-email-login'); ?></h3>
                <p><?php echo esc_html($stats['sent_failed']); ?></p>
            </div>
        </div>
        <div class="stat-row">
            <div class="stat-box received-success">
                <h3><?php _e('接收成功', 'kim-email-login'); ?></h3>
                <p><?php echo esc_html($stats['received_success']); ?></p>
            </div>
            <div class="stat-box received-failed">
                <h3><?php _e('接收失败', 'kim-email-login'); ?></h3>
                <p><?php echo esc_html($stats['received_failed']); ?></p>
            </div>
        </div>
        <div class="clear"></div>
        <p>
            <a href="<?php echo admin_url('options-general.php?page=kim_email_login'); ?>" class="button">
                <?php _e('配置设置', 'kim-email-login'); ?>
            </a>
        </p>
    </div>
    <style>
        .kim-email-stats .stat-row {
            display: flex;
            margin-bottom: 10px;
        }
        .kim-email-stats .stat-box {
            flex: 1;
            margin-right: 10px;
            background: #f5f5f5;
            padding: 15px;
            border-radius: 3px;
            text-align: center;
        }
        .kim-email-stats .stat-box:last-child {
            margin-right: 0;
        }
        .kim-email-stats .stat-box h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
        }
        .kim-email-stats .stat-box p {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }
        .kim-email-stats .stat-box.sent-success {
            border-left: 4px solid #46b450;
        }
        .kim-email-stats .stat-box.sent-failed {
            border-left: 4px solid #dc3232;
        }
        .kim-email-stats .stat-box.received-success {
            border-left: 4px solid #00a0d2;
        }
        .kim-email-stats .stat-box.received-failed {
            border-left: 4px solid #ffba00;
        }
        .kim-email-stats .clear {
            clear: both;
        }
    </style>
    <?php
}

// 设置页面
function kim_email_login_settings_page() {
    $capability = get_option('kim_email_login_capability', 'manage_options');
    if (!current_user_can($capability)) {
        wp_die(__('您没有足够的权限访问此页面。', 'kim-email-login'));
    }
    
    // 保存设置
    if (isset($_POST['kim_email_login_save']) && check_admin_referer('kim_email_login_save_settings')) {
        $settings = array(
            'smtp_host'       => sanitize_text_field($_POST['smtp_host']),
            'smtp_port'       => absint($_POST['smtp_port']),
            'smtp_username'   => sanitize_text_field($_POST['smtp_username']),
            'smtp_password'   => kim_email_login_encrypt($_POST['smtp_password']),
            'smtp_encryption' => in_array($_POST['smtp_encryption'], array('tls', 'ssl')) ? $_POST['smtp_encryption'] : 'tls',
            'from_email'      => is_email($_POST['from_email']) ? $_POST['from_email'] : '',
            'from_name'       => sanitize_text_field($_POST['from_name']),
            'disable_wp_mail' => isset($_POST['disable_wp_mail']),
            'debug_mode'      => isset($_POST['debug_mode']),
            'smtp_timeout'    => absint($_POST['smtp_timeout']),
            'smtp_auto_tls'   => isset($_POST['smtp_auto_tls'])
        );
        
        update_option(KIM_EMAIL_LOGIN_OPTION, $settings);
        
        if (isset($_POST['capability'])) {
            update_option('kim_email_login_capability', sanitize_text_field($_POST['capability']));
        }
        
        if (isset($_POST['test_connection'])) {
            kim_email_login_test_connection($settings);
        }
        
        add_settings_error(
            'kim_email_login_messages', 
            'kim_email_login_message', 
            __('设置已保存', 'kim-email-login'), 
            'updated'
        );
    }
    
    // 发送测试邮件
    if (isset($_POST['kim_email_login_test_email']) && check_admin_referer('kim_email_login_test_email')) {
        $to = sanitize_email($_POST['test_email']);
        $subject = isset($_POST['test_subject']) ? sanitize_text_field($_POST['test_subject']) : __('来自 Kim 邮件登录的测试邮件', 'kim-email-login');
        $message = isset($_POST['test_message']) ? wp_kses_post($_POST['test_message']) : __('这是一封测试邮件，用于确认您的 SMTP 配置是否正确。', 'kim-email-login');
        
        kim_email_login_send_test_email($to, $subject, $message);
    }
    
    // 重置统计数据
    if (isset($_POST['reset_stats']) && check_admin_referer('kim_email_login_reset_stats')) {
        update_option(KIM_EMAIL_STATS_OPTION, array(
            'sent_success' => 0,
            'sent_failed' => 0,
            'received_success' => 0,
            'received_failed' => 0
        ));
        add_settings_error(
            'kim_email_login_messages', 
            'kim_email_login_message', 
            __('统计数据已重置', 'kim-email-login'), 
            'updated'
        );
    }
    
    $settings = kim_email_login_get_settings();
    $stats = get_option(KIM_EMAIL_STATS_OPTION);
    
    ?>
    <div class="wrap kim-email-login-settings">
        <h1><?php _e('Kim 邮件登录设置', 'kim-email-login'); ?></h1>
        
        <?php settings_errors('kim_email_login_messages'); ?>
        
        <div class="kim-email-login-tabs">
            <h2 class="nav-tab-wrapper">
                <a href="#settings" class="nav-tab nav-tab-active"><?php _e('SMTP 设置', 'kim-email-login'); ?></a>
                <a href="#test" class="nav-tab"><?php _e('测试邮件', 'kim-email-login'); ?></a>
                <a href="#stats" class="nav-tab"><?php _e('统计信息', 'kim-email-login'); ?></a>
                <a href="#advanced" class="nav-tab"><?php _e('高级设置', 'kim-email-login'); ?></a>
            </h2>
            
            <div id="settings" class="tab-content active">
                <form method="POST">
                    <?php wp_nonce_field('kim_email_login_save_settings'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="smtp_host"><?php _e('SMTP 主机', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="text" name="smtp_host" id="smtp_host" value="<?php echo esc_attr($settings['smtp_host']); ?>" class="regular-text" />
                                <p class="description"><?php _e('SMTP 服务器地址（例如：smtp.example.com）。', 'kim-email-login'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="smtp_port"><?php _e('SMTP 端口', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="number" name="smtp_port" id="smtp_port" value="<?php echo esc_attr($settings['smtp_port']); ?>" class="small-text" min="1" max="65535" />
                                <p class="description"><?php _e('通常 TLS 使用 587，SSL 使用 465，无加密时可用 25。', 'kim-email-login'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="smtp_encryption"><?php _e('加密方式', 'kim-email-login'); ?></label></th>
                            <td>
                                <select name="smtp_encryption" id="smtp_encryption">
                                    <option value="tls" <?php selected($settings['smtp_encryption'], 'tls'); ?>><?php _e('TLS', 'kim-email-login'); ?></option>
                                    <option value="ssl" <?php selected($settings['smtp_encryption'], 'ssl'); ?>><?php _e('SSL', 'kim-email-login'); ?></option>
                                    <option value="" <?php selected($settings['smtp_encryption'], ''); ?>><?php _e('无加密', 'kim-email-login'); ?></option>
                                </select>
                                <p class="description"><?php _e('选择要使用的加密协议。', 'kim-email-login'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="smtp_username"><?php _e('SMTP 用户名', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="text" name="smtp_username" id="smtp_username" value="<?php echo esc_attr($settings['smtp_username']); ?>" class="regular-text" />
                                <p class="description"><?php _e('您的 SMTP 账户用户名。', 'kim-email-login'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="smtp_password"><?php _e('SMTP 密码', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="password" name="smtp_password" id="smtp_password" value="<?php echo esc_attr(kim_email_login_decrypt($settings['smtp_password'])); ?>" class="regular-text" autocomplete="off" />
                                <p class="description"><?php _e('您的 SMTP 账户密码。', 'kim-email-login'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="from_email"><?php _e('发件人邮箱', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="email" name="from_email" id="from_email" value="<?php echo esc_attr($settings['from_email']); ?>" class="regular-text" />
                                <p class="description"><?php _e('发送邮件时使用的邮箱地址，留空则使用 WordPress 默认设置。', 'kim-email-login'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="from_name"><?php _e('发件人名称', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="text" name="from_name" id="from_name" value="<?php echo esc_attr($settings['from_name']); ?>" class="regular-text" />
                                <p class="description"><?php _e('发送邮件时使用的名称。', 'kim-email-login'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="disable_wp_mail"><?php _e('禁用 WordPress 默认邮件', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="checkbox" name="disable_wp_mail" id="disable_wp_mail" value="1" <?php checked($settings['disable_wp_mail'], true); ?> />
                                <label for="disable_wp_mail"><?php _e('禁用 WordPress 默认邮件函数，仅使用 SMTP 发送', 'kim-email-login'); ?></label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="debug_mode"><?php _e('调试模式', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="checkbox" name="debug_mode" id="debug_mode" value="1" <?php checked($settings['debug_mode'], true); ?> />
                                <label for="debug_mode"><?php _e('启用调试模式，记录发送邮件错误', 'kim-email-login'); ?></label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="smtp_timeout"><?php _e('SMTP 超时', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="number" name="smtp_timeout" id="smtp_timeout" value="<?php echo esc_attr($settings['smtp_timeout']); ?>" class="small-text" min="5" max="60" />
                                <p class="description"><?php _e('SMTP 连接超时时间（秒）。', 'kim-email-login'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="smtp_auto_tls"><?php _e('自动 TLS', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="checkbox" name="smtp_auto_tls" id="smtp_auto_tls" value="1" <?php checked($settings['smtp_auto_tls'], true); ?> />
                                <label for="smtp_auto_tls"><?php _e('启用自动 TLS 协商（某些服务器需要禁用此选项）', 'kim-email-login'); ?></label>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <input type="submit" name="kim_email_login_save" value="<?php _e('保存设置', 'kim-email-login'); ?>" class="button-primary" />
                        <input type="submit" name="test_connection" value="<?php _e('保存并测试连接', 'kim-email-login'); ?>" class="button-secondary" />
                    </p>
                </form>
            </div>
            
            <div id="test" class="tab-content">
                <form method="POST">
                    <?php wp_nonce_field('kim_email_login_test_email'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="test_email"><?php _e('收件人邮箱', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="email" name="test_email" id="test_email" value="<?php echo esc_attr(get_option('admin_email')); ?>" class="regular-text" required />
                                <p class="description"><?php _e('用于发送测试邮件的邮箱地址。', 'kim-email-login'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="test_subject"><?php _e('主题', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="text" name="test_subject" id="test_subject" value="<?php _e('来自 Kim 邮件登录的测试邮件', 'kim-email-login'); ?>" class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="test_message"><?php _e('内容', 'kim-email-login'); ?></label></th>
                            <td>
                                <textarea name="test_message" id="test_message" rows="5" class="large-text"><?php _e('这是一封测试邮件，用于确认您的 SMTP 配置是否正确。', 'kim-email-login'); ?></textarea>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <input type="submit" name="kim_email_login_test_email" value="<?php _e('发送测试邮件', 'kim-email-login'); ?>" class="button-primary" />
                    </p>
                </form>
            </div>
            
            <div id="stats" class="tab-content">
                <div class="statistics-container">
                    <div class="stat-row">
                        <div class="stat-box sent-success">
                            <h3><?php _e('发送成功', 'kim-email-login'); ?></h3>
                            <p><?php echo esc_html($stats['sent_success']); ?></p>
                        </div>
                        <div class="stat-box sent-failed">
                            <h3><?php _e('发送失败', 'kim-email-login'); ?></h3>
                            <p><?php echo esc_html($stats['sent_failed']); ?></p>
                        </div>
                    </div>
                    <div class="stat-row">
                        <div class="stat-box received-success">
                            <h3><?php _e('接收成功', 'kim-email-login'); ?></h3>
                            <p><?php echo esc_html($stats['received_success']); ?></p>
                        </div>
                        <div class="stat-box received-failed">
                            <h3><?php _e('接收失败', 'kim-email-login'); ?></h3>
                            <p><?php echo esc_html($stats['received_failed']); ?></p>
                        </div>
                    </div>
                    <div class="clear"></div>
                    
                    <form method="POST" style="margin-top: 20px;">
                        <?php wp_nonce_field('kim_email_login_reset_stats'); ?>
                        <p>
                            <input type="submit" name="reset_stats" value="<?php _e('重置统计数据', 'kim-email-login'); ?>" class="button" onclick="return confirm('<?php _e('确定要重置统计数据吗？', 'kim-email-login'); ?>');" />
                        </p>
                    </form>
                </div>
            </div>
            
            <div id="advanced" class="tab-content">
                <h3><?php _e('高级设置', 'kim-email-login'); ?></h3>
                <p><?php _e('仅当您了解相关设置含义时，才修改以下内容。', 'kim-email-login'); ?></p>
                
                <form method="POST">
                    <?php wp_nonce_field('kim_email_login_save_settings'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="capability"><?php _e('所需权限', 'kim-email-login'); ?></label></th>
                            <td>
                                <input type="text" name="capability" id="capability" value="<?php echo esc_attr(get_option('kim_email_login_capability', 'manage_options')); ?>" class="regular-text" />
                                <p class="description"><?php _e('访问此设置页面所需的 WordPress 权限。', 'kim-email-login'); ?></p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <input type="submit" name="kim_email_login_save" value="<?php _e('保存设置', 'kim-email-login'); ?>" class="button-primary" />
                    </p>
                </form>
            </div>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('.kim-email-login-tabs .nav-tab-wrapper a').click(function(e) {
            e.preventDefault();
            var tab = $(this).attr('href');
            
            $('.kim-email-login-tabs .nav-tab-wrapper a').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            
            $('.kim-email-login-tabs .tab-content').removeClass('active');
            $(tab).addClass('active');
        });
    });
    </script>
    
    <style>
    .kim-email-login-settings .kim-email-login-tabs {
        margin-top: 20px;
    }
    
    .kim-email-login-settings .tab-content {
        display: none;
        padding: 20px;
        background: #fff;
        border: 1px solid #ddd;
        border-top: none;
    }
    
    .kim-email-login-settings .tab-content.active {
        display: block;
    }
    
    .kim-email-login-settings .statistics-container {
        max-width: 600px;
    }
    
    .kim-email-login-settings .stat-row {
        display: flex;
        margin-bottom: 10px;
    }
    
    .kim-email-login-settings .stat-box {
        flex: 1;
        margin-right: 10px;
        background: #f5f5f5;
        padding: 15px;
        border-radius: 3px;
        text-align: center;
    }
    
    .kim-email-login-settings .stat-box:last-child {
        margin-right: 0;
    }
    
    .kim-email-login-settings .stat-box h3 {
        margin: 0 0 10px 0;
        font-size: 14px;
    }
    
    .kim-email-login-settings .stat-box p {
        margin: 0;
        font-size: 24px;
        font-weight: bold;
    }
    
    .kim-email-login-settings .stat-box.sent-success {
        border-left: 4px solid #46b450;
    }
    
    .kim-email-login-settings .stat-box.sent-failed {
        border-left: 4px solid #dc3232;
    }
    
    .kim-email-login-settings .stat-box.received-success {
        border-left: 4px solid #00a0d2;
    }
    
    .kim-email-login-settings .stat-box.received-failed {
        border-left: 4px solid #ffba00;
    }
    
    .kim-email-login-settings .clear {
        clear: both;
    }
    </style>
    <?php
}

// 测试 SMTP 连接（改进版）
function kim_email_login_test_connection($settings, $silent = false) {
    if (empty($settings['smtp_host'])) {
        throw new Exception(__('SMTP 主机不能为空', 'kim-email-login'));
    }
    if (empty($settings['smtp_port'])) {
        throw new Exception(__('SMTP 端口不能为空', 'kim-email-login'));
    }
    if (empty($settings['smtp_username'])) {
        throw new Exception(__('SMTP 用户名不能为空', 'kim-email-login'));
    }
    
    require_once ABSPATH . WPINC . '/class-phpmailer.php';
    require_once ABSPATH . WPINC . '/class-smtp.php';
    
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host = $settings['smtp_host'];
        $mail->Port = $settings['smtp_port'];
        $mail->SMTPAuth = true;
        $mail->Username = $settings['smtp_username'];
        $mail->Password = kim_email_login_decrypt($settings['smtp_password']);
        $mail->Timeout = isset($settings['smtp_timeout']) ? $settings['smtp_timeout'] : 15;
        
        if (!empty($settings['smtp_encryption'])) {
            $mail->SMTPSecure = $settings['smtp_encryption'];
        }
        
        // 设置自动 TLS 选项
        $mail->SMTPAutoTLS = isset($settings['smtp_auto_tls']) ? $settings['smtp_auto_tls'] : true;
        
        $mail->SMTPDebug = $settings['debug_mode'] ? 2 : 0;
        $mail->Debugoutput = function($str, $level) {
            if ($level === 2) {
                error_log('Kim SMTP Debug: ' . $str);
            }
        };
        
        // 测试连接
        if (!$mail->smtpConnect()) {
            throw new Exception($mail->ErrorInfo);
        }
        
        $mail->smtpClose();
        
        if (!$silent) {
            add_settings_error(
                'kim_email_login_messages', 
                'kim_email_login_message', 
                __('SMTP 连接成功！', 'kim-email-login'), 
                'updated'
            );
        }
        return true;
    } catch (Exception $e) {
        $error = $e->getMessage();
        $suggestion = '';
        
        if (stripos($error, 'authentication') !== false) {
            $suggestion = __('建议检查 SMTP 用户名和密码是否正确。', 'kim-email-login');
        } elseif (stripos($error, 'connect') !== false) {
            $suggestion = __('建议检查 SMTP 主机地址和端口是否正确，以及服务器是否允许外部连接。', 'kim-email-login');
        } elseif (stripos($error, 'Encryption') !== false) {
            $suggestion = __('建议确认 SMTP 服务器要求的加密方式，可能需要调整加密协议。', 'kim-email-login');
        } else {
            $suggestion = __('请检查您的 SMTP 配置是否正确，并确认网络连接正常。', 'kim-email-login');
        }
        
        if (!$silent) {
            add_settings_error(
                'kim_email_login_messages', 
                'kim_email_login_message', 
                sprintf(__('SMTP 连接失败：%s<br>%s', 'kim-email-login'), $error, $suggestion), 
                'error'
            );
        }
        throw $e;
    }
}

// 发送测试邮件（改进版）
function kim_email_login_send_test_email($to, $subject, $message) {
    $settings = kim_email_login_get_settings();
    $stats = get_option(KIM_EMAIL_STATS_OPTION);
    
    $headers = array('Content-Type: text/html; charset=UTF-8');
    
    if (!empty($settings['from_email'])) {
        $from_name = !empty($settings['from_name']) ? $settings['from_name'] : get_bloginfo('name');
        $headers[] = 'From: ' . $from_name . ' <' . $settings['from_email'] . '>';
    }
    
    // 记录发送尝试
    $mail_sent = wp_mail($to, $subject, $message, $headers);
    
    if ($mail_sent) {
        $stats['sent_success']++;
        add_settings_error(
            'kim_email_login_messages', 
            'kim_email_login_message', 
            sprintf(__('测试邮件已成功发送到 %s', 'kim-email-login'), $to), 
            'updated'
        );
    } else {
        $stats['sent_failed']++;
        add_settings_error(
            'kim_email_login_messages', 
            'kim_email_login_message', 
            __('测试邮件发送失败，请检查 SMTP 配置。', 'kim-email-login'), 
            'error'
        );
        
        if (!empty($settings['debug_mode'])) {
            error_log('Kim 邮件登录 - 测试邮件发送失败：' . $to);
        }
    }
    
    update_option(KIM_EMAIL_STATS_OPTION, $stats);
    return $mail_sent;
}

// 覆盖 WordPress 默认邮件函数
function kim_email_login_override_mail($phpmailer) {
    $settings = kim_email_login_get_settings();
    
    if (empty($settings['disable_wp_mail'])) {
        return;
    }
    
    try {
        // 设置 SMTP 配置
        $phpmailer->isSMTP();
        $phpmailer->Host = $settings['smtp_host'];
        $phpmailer->Port = $settings['smtp_port'];
        $phpmailer->SMTPAuth = true;
        $phpmailer->Username = $settings['smtp_username'];
        $phpmailer->Password = kim_email_login_decrypt($settings['smtp_password']);
        $phpmailer->Timeout = isset($settings['smtp_timeout']) ? $settings['smtp_timeout'] : 15;
        
        if (!empty($settings['smtp_encryption'])) {
            $phpmailer->SMTPSecure = $settings['smtp_encryption'];
        }
        
        // 设置自动 TLS 选项
        $phpmailer->SMTPAutoTLS = isset($settings['smtp_auto_tls']) ? $settings['smtp_auto_tls'] : true;
        
        // 设置发件人信息
        if (!empty($settings['from_email'])) {
            $from_name = !empty($settings['from_name']) ? $settings['from_name'] : get_bloginfo('name');
            $phpmailer->setFrom($settings['from_email'], $from_name);
        }
        
        // 设置调试模式
        if (!empty($settings['debug_mode'])) {
            $phpmailer->SMTPDebug = 2;
            $phpmailer->Debugoutput = function($str, $level) {
                error_log('Kim 邮件登录 - SMTP 调试: ' . $str);
            };
        }
    } catch (Exception $e) {
        if (!empty($settings['debug_mode'])) {
            error_log('Kim 邮件登录 - SMTP 初始化失败: ' . $e->getMessage());
        }
    }
}

// 如果启用了禁用 WordPress 默认邮件，则挂接覆盖函数
$settings = kim_email_login_get_settings();
if (!empty($settings['disable_wp_mail'])) {
    add_action('phpmailer_init', 'kim_email_login_override_mail');
}

// 邮件统计记录（改进版）
function kim_email_login_track_email($result) {
    $settings = kim_email_login_get_settings();
    $stats = get_option(KIM_EMAIL_STATS_OPTION);
    
    if ($result instanceof WP_Error) {
        // 发送失败
        $stats['sent_failed']++;
        
        if (!empty($settings['debug_mode'])) {
            error_log('Kim 邮件登录 - 邮件发送失败: ' . $result->get_error_message());
        }
    } elseif (is_array($result) && isset($result['response'])) {
        // 接收状态
        if ($result['response']['code'] >= 200 && $result['response']['code'] < 300) {
            $stats['received_success']++;
        } else {
            $stats['received_failed']++;
            
            if (!empty($settings['debug_mode'])) {
                error_log('Kim 邮件登录 - 邮件接收失败: ' . print_r($result, true));
            }
        }
    } else {
        // 发送成功
        $stats['sent_success']++;
    }
    
    update_option(KIM_EMAIL_STATS_OPTION, $stats);
}

// 挂钩邮件发送事件
add_action('wp_mail_succeeded', 'kim_email_login_track_email');
add_action('wp_mail_failed', 'kim_email_login_track_email');

// 在插件列表页添加设置链接
function kim_email_login_add_action_links($links) {
    $settings_link = '<a href="' . admin_url('options-general.php?page=kim_email_login') . '">' . __('设置', 'kim-email-login') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'kim_email_login_add_action_links');

// 每周报告（改进版）
function kim_email_login_send_weekly_report() {
    $settings = kim_email_login_get_settings();
    $stats = get_option(KIM_EMAIL_STATS_OPTION);
    
    if (empty($settings['from_email'])) {
        return;
    }
    
    $to = get_option('admin_email');
    $subject = __('Kim 邮件登录 - 每周统计报告', 'kim-email-login');
    $message = sprintf(
        __('<p>以下是过去一周的邮件统计：</p>
        <ul>
            <li>发送成功：%d</li>
            <li>发送失败：%d</li>
            <li>接收成功：%d</li>
            <li>接收失败：%d</li>
        </ul>
        <p>您可以登录 WordPress 后台查看详细统计信息。</p>', 'kim-email-login'),
        $stats['sent_success'],
        $stats['sent_failed'],
        $stats['received_success'],
        $stats['received_failed']
    );
    
    $headers = array('Content-Type: text/html; charset=UTF-8');
    $from_name = !empty($settings['from_name']) ? $settings['from_name'] : get_bloginfo('name');
    $headers[] = 'From: ' . $from_name . ' <' . $settings['from_email'] . '>';
    
    wp_mail($to, $subject, $message, $headers);
}
add_action('kim_email_login_weekly_event', 'kim_email_login_send_weekly_report');